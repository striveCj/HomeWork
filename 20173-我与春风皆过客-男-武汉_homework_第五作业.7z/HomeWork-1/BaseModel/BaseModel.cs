﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork_1.BaseModel
{
    public class BaseModel
    {
        public int Id { get; set; }
    }
}
