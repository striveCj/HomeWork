﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork_1.Model
{
    /// <summary>
    /// 数据库返回字段信息
    /// </summary>
   public class DbFieldResultDto
    {
        public string Name { get; set; }

        public string Type { get; set; }
    }
}
