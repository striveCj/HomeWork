﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork_1.Model
{
    /// <summary>
    /// 代码生成方法入参
    /// </summary>
    public class CodeGeneratorDto
    {
        public string TempStr { get; set; }

        public string TableName { get; set; }
    }
}
